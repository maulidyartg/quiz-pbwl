

<?php $__env->startSection('content'); ?>
<h2>Add Pelanggan</h2>

<form action="<?php echo e(route('pel_store')); ?>" method="POST" class="mt-3">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="id">Golongan:</label>
        <select class="form-select" id="id" name="gol_id" required>
            <?php $__currentLoopData = $golongans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($golongan->id); ?>"><?php echo e($golongan->gol_nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="pel_no">No Pelanggan:</label>
        <input type="text" name="pel_no" class="form-control" placeholder="Masukkan No Pelanggan" required>
    </div>
    <div class="mb-3">
        <label for="pel_nama">Nama Pelanggan:</label>
        <input type="text" name="pel_nama" class="form-control" placeholder="Masukkan Nama Pelanggan" required>
    </div>
    <div class="mb-3">
        <label for="pel_alamat">Alamat:</label>
        <input type="text" name="pel_alamat" class="form-control" placeholder="Masukkan Alamat" required>
    </div>
    <div class="mb-3">
        <label for="pel_hp">No HP:</label>
        <input type="text" name="pel_hp" class="form-control" placeholder="Masukkan No HP" required>
    </div>
    <div class="mb-3">
        <label for="pel_ktp">KTP:</label>
        <input type="text" name="pel_ktp" class="form-control" placeholder="Masukkan No KTP" required>
    </div>
    <div class="mb-3">
        <label for="pel_seri">Seri:</label>
        <input type="text" name="pel_seri" class="form-control" placeholder="Masukkan No Seri" required>
    </div>
    <div class="mb-3">
        <label for="pel_meteran">Meteran:</label>
        <input type="text" name="pel_meteran" class="form-control" placeholder="Masukkan No Meteran" required>
    </div>
    <div class="mb-3">
        <label for="pel_aktif">Aktif:</label>
        <select name="pel_aktif" class="form-select" required>
            <option value="">Pilih Status</option>
            <option value="Y">Aktif</option>
            <option value="N">Non Aktif</option>
        </select>
    </div>  
    <div class="mb-3">
        <label for="id">User:</label>
        <select class="form-select" id="id" name="user_id" required>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <input type="submit" value="SAVE" class="btn btn-primary">
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizdiva-pbwl\resources\views/pelanggan/create.blade.php ENDPATH**/ ?>